interface Seat {
    row: number;
    column: number;
    occupied: boolean;
  }